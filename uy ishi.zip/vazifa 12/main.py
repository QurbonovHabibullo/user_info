'''1'''
# print("Hello World")

# print("Salom dunyoni chiqardik")

# print("Assalomu alaykum")



'''5'''
def validatsiya_phone(phone):
    return phone.startswith("+998") and len(phone) == 13 and phone[1:].isdigit()

def validatsiya_age(age):
    return age.isdigit() and int(age) > 0

def get_user_info():
    while True:
        name = input("Ismiyizni kiriting: ")
        lastname = input("Familyangizni kiriting: ")
        age = input("Yoshiyizni kiriting: ")
        if not validatsiya_age(age):
            print("yoshimiz butun va musbat yani 0 dan katta bolishi kerak")
            continue
        age = int(age)
        
        phone = input("Telefon raqamni kiriting (+998 bilan boshlanishi kerak): ")
        if not validatsiya_phone(phone):
            print("Telefon raqami +998 bilan boshlanishi va 12 ta raqamdan iborat bo'lishi kerak!")
            continue
        
        email = input("Email manzil kiriting: ")
        address = input("Yashash manzilni kiriting: ")
        
        return name, lastname, age, phone, email, address

def save_user_info(user_id, name, lastname, age, phone, email, address):
    with open("users_info.txt", "a") as file:
        file.write(f"ID: {user_id}, Name: {name}, Lastname: {lastname}, Age: {age}, Phone: {phone}, Email: {email}, Address: {address}\n")

def main():
    user_id = 1
    while True:
        print("\nFoydalanuvchi ma'lumotlarini kiriting:")
        name, lastname, age, phone, email, address = get_user_info()
        save_user_info(user_id, name, lastname, age, phone, email, address)
        print("Ma'lumotlar saqlandi.")
        user_id += 1

if __name__ == "__main__":
    main()
