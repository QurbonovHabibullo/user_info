// const number = -2
// if ( number > 0) {
//     console.log("berilgan son musbat")
// } else {console.log("berilgan son manfiy")}
// -----------------------
// const number = -2
// if (number > 0) {
//     console.log("berilgan son musbat")
// } else if (number == 0) {
//     console.log("berilgan son nolga teng")
// } else {
//     console.log("berilgan son manfiy")
// }

// =====================================
// 1-topshiriq
// const number = 3
// if (number % 2 == 0) {
//     console.log("kiritilgan son musbat")
// }else {
//     console.log("kiritilgan son manfiy")
// }

// 2-topshiriq
// const a = 5
// const b = 10
// if (a > b) {
//     console.log("a soni b dan katta")
// } else {
//     console.log("a soni b kichkina")
// }

// 3-toshiriq
// const number = 99
// if (number > 100) {
//     console.log("sonimiz 100 dan katta")
// } else {
//     console.log("sonimiz 100 dan kichik")
// }

// 4-topshiriq
// const number = 0
// if (number > 0) {
//     console.log("sonimiz musbat")
// } else if(number == 0) {
//     console.log("sonimiz 0 ga teng")
// }
// else {
//     console.log("sonimiz manfiy")
// }

// 5-tipshiriq
const age = 11
if (age > 18) {
    console.log("yoshingiz 18dan katta")
} else {
    console.log("yoshingiz 18 dan kichik")
}